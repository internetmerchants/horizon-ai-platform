#!/bin/bash
# manage.sh - Service management script
# Place this in: /Users/2021imac/Desktop/Work/AI/Project/manage.sh

# ./manage.sh start        - Start all services
# ./manage.sh stop         - Stop all services
# ./manage.sh status       - Check status
# ./manage.sh logs backend - View backend logs

PROJECT_DIR="/Users/2021imac/Desktop/Work/AI/Project"

case "$1" in
  start)
    echo "Starting services..."
    
    # Start PostgreSQL
    docker start pg16 2>/dev/null || echo "PostgreSQL already running"
    
    # Start backend
    cd $PROJECT_DIR/platform/backend
    source venv/bin/activate
    uvicorn app.main:app --reload --port 8000 &
    
    # Start frontend (if exists)
    if [ -d "$PROJECT_DIR/frontend" ]; then
      cd $PROJECT_DIR/frontend
      npm run dev &  # Use 'dev' not 'start' for development
    fi
    
    echo "Services started!"
    ;;
    
  stop)
    echo "Stopping services..."
    pkill -f "uvicorn app.main:app"
    pkill -f "npm"
    echo "Services stopped!"
    ;;
    
  *)
    echo "Usage: $0 {start|stop}"
    ;;
esac
