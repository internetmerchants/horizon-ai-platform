mkdir CenteredAuthLayout && mv CenteredAuthLayout.tsx CenteredAuthLayout/page.tsx && 
mkdir DefaultAuthLayout && mv DefaultAuthLayout.tsx DefaultAuthLayout/page.tsx && 
mkdir PricingAuthLayout && mv PricingAuthLayout.tsx PricingAuthLayout/page.tsx

mv forgot-password ../../app/auth && mv lock ../../app/auth && mv main ../../app/auth && mv sign-in ../../app/auth && mv sign-up ../../app/auth && mv verification ../../app/auth 


mkdir centered && mv centered.tsx centered/page.tsx && 
mkdir default && mv default.tsx default/page.tsx 
